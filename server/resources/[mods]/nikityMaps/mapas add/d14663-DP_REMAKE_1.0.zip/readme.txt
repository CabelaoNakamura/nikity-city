Designer Penthouse Remake

This is a real remake based on MLO that works without mapbuilder. 
The house is in one of the best locations for a penthouse with a 360 degree view of the whole of los santos. 
It comes with a new 8 car garage in a dark design (also MLO) with direct access to the street.

--------------
DEVELOPED AND DESIGNED WITH

3DS MAX
PHOTOSHOP
CODEWALKER
GIMS EVO
PORTAL HELPER SCRIPT
GTA V MAP HELPER
MENYOO

--------------
FEATURES

EXCLUSIVE GARAGE FOR 8 CARS
LIVINGROOM
MASTER BEDROOM
GUEST BEDROOM
GUEST BATHROOM
OPEN CLOSET
KITCHEN
ENTRANCE AREA
ROOFTOP
TERRACE
POOL
POOLHOUSE
SEVERAL CHILL SPOTS IN AND OUTDOOR
ETC.

--------------
INSTALL: DESIGNER PENTHOUSE REMAKE

NOTE: do not skip step 3. and 4. these files remove the occlusion boxes at the garage door. 
for explanation, occlusion boxes reduce the visibility of 3D assets to optimize the performance.
the garage is a new interior, this occlusion boxes is no longer needed.
or simply said, without you have an ugly bug.

1. run OpenIV.

2. go to Main Files, drag and drop the folder dp_remake in the following path. --> mods\update\x64\dlcpacks

3. go to Replace Files, drag and drop the file dt1_occl_03 in the following path. --> mods\update\x64\dlcpacks\patchday1ng\dlc.rpf\x64\levels\gta5\_citye\downtown_01\dt1_occl.rpf

4. go to Replace Files, drag and drop the file hei_dt1_occl_03 in the following path. --> mods\update\update.rpf\dlc_patch\mpheist\x64\levels\gta5\_citye\downtown_01\dt1_occl.rpf

5. go to. --> mods\update\update.rpf\common\data open dlclist.xml and add the line <Item>dlcpacks:/dp_remake/</Item>

that's it

-------------
INSTALL: OPTIONAL STUFF

1. run OpenIV.

2. go to Optional -> dp_remake_meta.rpf, drag and drop the files dp_building_ext_col and designer_penthouse.ytyp in the following path. --> mods\update\x64\dlcpacks\dp_remake\dlc.rpf\x64\levels\gta5\dp_remake_meta.rpf\

3. go to Optional -> dp_remake_assets.rpf drag and drop the files dp_building_ext.ydr and dp_delta_int.ydr in the following path. --> mods\update\x64\dlcpacks\dp_remake\dlc.rpf\x64\levels\gta5\dp_remake_assets.rpf\

--------------
INSTALL: MENYOO PARTY SCENARIO

1. go to Menyoo, drag and drop the file EGO-X Penthouse Poolparty.xml in the following path. Grand Theft Auto V\menyooStuff\Spooner. load the file ingame with the menyoo-spooner.
